const API = '/api/requests';
const form = document.getElementById('pickupForm');
const message = document.getElementById('formMessage');
const rows = document.getElementById('requestRows');

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  message.className = '';
  message.textContent = 'Submitting your request…';
  const data = Object.fromEntries(new FormData(form).entries());
  data.weightKg = data.weightKg ? Number(data.weightKg) : null;
  data.preferredDate = data.preferredDate || null;
  try {
    const response = await fetch(API, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(data)
    });
    if (!response.ok) {
      const body = await response.json().catch(() => ({}));
      throw new Error(body.message || 'Please check your details and try again.');
    }
    const created = await response.json();
    form.reset();
    message.className = 'success';
    message.textContent = `Request #${created.id} submitted successfully. Status: Pending.`;
    await loadRequests();
    document.getElementById('dashboard').scrollIntoView({behavior: 'smooth', block: 'start'});
  } catch (error) {
    message.className = 'error';
    message.textContent = error.message || 'Could not submit request. Is the server running?';
  }
});

async function loadRequests() {
  try {
    const response = await fetch(API);
    if (!response.ok) throw new Error('Unable to load requests');
    const requests = await response.json();
    document.getElementById('totalCount').textContent = requests.length;
    document.getElementById('pendingCount').textContent = requests.filter(r => r.status === 'Pending').length;
    document.getElementById('doneCount').textContent = requests.filter(r => ['Collected','Recycled'].includes(r.status)).length;
    if (!requests.length) {
      rows.innerHTML = '<tr><td colspan="6" class="empty">No pickup requests yet. Submit the first request above.</td></tr>';
      return;
    }
    rows.innerHTML = requests.map(r => `
      <tr>
        <td><strong>#${r.id}</strong></td>
        <td><strong>${escapeHtml(r.customerName)}</strong><br>${escapeHtml(r.email)}</td>
        <td>${escapeHtml(r.category)}${r.weightKg ? `<br><span style="color:#879188">${Number(r.weightKg).toFixed(1)} kg</span>` : ''}</td>
        <td>${r.preferredDate || 'Not specified'}</td>
        <td><span class="status ${r.status.toLowerCase()}">${escapeHtml(r.status)}</span></td>
        <td><select class="action-select" aria-label="Update status for request ${r.id}" onchange="updateStatus(${r.id}, this.value)">
          ${['Pending','Scheduled','Collected','Recycled','Rejected'].map(s => `<option ${s === r.status ? 'selected' : ''}>${s}</option>`).join('')}
        </select><button class="delete-btn" onclick="deleteRequest(${r.id})" aria-label="Delete request ${r.id}">Delete</button></td>
      </tr>`).join('');
  } catch (error) {
    rows.innerHTML = '<tr><td colspan="6" class="empty">Could not connect to the backend. Start it with <code>mvn spring-boot:run</code>.</td></tr>';
  }
}

async function updateStatus(id, status) {
  try {
    const response = await fetch(`${API}/${id}/status`, {
      method: 'PATCH', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({status})
    });
    if (!response.ok) throw new Error();
    await loadRequests();
  } catch { alert('Status update failed. Please try again.'); }
}

async function deleteRequest(id) {
  if (!confirm(`Delete pickup request #${id}? This cannot be undone.`)) return;
  try {
    const response = await fetch(`${API}/${id}`, {method:'DELETE'});
    if (!response.ok) throw new Error();
    await loadRequests();
  } catch { alert('Could not delete this request. Please try again.'); }
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({
    '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'
  }[char]));
}

document.getElementById('refreshBtn').addEventListener('click', loadRequests);
loadRequests();
