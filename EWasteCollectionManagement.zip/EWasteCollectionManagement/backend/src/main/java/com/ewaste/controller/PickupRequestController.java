package com.ewaste.controller;

import com.ewaste.model.PickupRequest;
import com.ewaste.repository.PickupRequestRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Map;
import java.util.Set;

@RestController
@RequestMapping("/api/requests")
public class PickupRequestController {
    private final PickupRequestRepository repository;
    private static final Set<String> STATUSES =
        Set.of("Pending", "Scheduled", "Collected", "Recycled", "Rejected");

    public PickupRequestController(PickupRequestRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public List<PickupRequest> all() {
        return repository.findAllByOrderByCreatedAtDesc();
    }

    @GetMapping("/{id}")
    public PickupRequest one(@PathVariable Long id) {
        return repository.findById(id)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Request not found"));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public PickupRequest create(@Valid @RequestBody PickupRequest request) {
        request.setId(null);
        request.setStatus("Pending");
        return repository.save(request);
    }

    @PatchMapping("/{id}/status")
    public PickupRequest updateStatus(@PathVariable Long id, @RequestBody Map<String, String> body) {
        String status = body.get("status");
        if (status == null || !STATUSES.contains(status)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid status");
        }
        PickupRequest request = one(id);
        request.setStatus(status);
        return repository.save(request);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        if (!repository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Request not found");
        }
        repository.deleteById(id);
    }
}
