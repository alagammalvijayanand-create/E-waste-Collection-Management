# E-Waste Collection Management System

A full-stack starter project with a responsive frontend and a Java Spring Boot backend.

## Features
- Submit an e-waste pickup request
- Capture customer name, email, phone, address, e-waste category, approximate weight, and preferred pickup date
- View submitted requests in the dashboard
- Update request status (Pending, Scheduled, Collected, Recycled, Rejected)
- Delete requests
- H2 database for local development; data persists in the local H2 file database

## Requirements
- Java 17+
- Maven 3.8+
- Internet connection the first time Maven downloads dependencies

## Run the project
1. Extract the ZIP.
2. Open a terminal inside `EWasteCollectionManagement/backend`.
3. Run:
   ```bash
   mvn spring-boot:run
   ```
4. Open http://localhost:8080 in your browser.

The frontend is served by Spring Boot from `backend/src/main/resources/static`.

## API endpoints
- `GET /api/requests` — list all pickup requests
- `GET /api/requests/{id}` — get one request
- `POST /api/requests` — create a request
- `PATCH /api/requests/{id}/status` — update status, JSON body: `{"status":"Scheduled"}`
- `DELETE /api/requests/{id}` — delete a request

## GitHub upload
Create a repository on GitHub, then from this project folder run:
```bash
git init
git add .
git commit -m "Add E-Waste Collection Management System"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the remote URL with your own repository URL.

## Notes
- This is an educational/demo project. Add authentication, authorization, validation hardening, and deployment configuration before using it with real customer data.
- H2 console (development only): http://localhost:8080/h2-console
  - JDBC URL: `jdbc:h2:file:./data/ewaste`
  - User: `sa`
  - Password: leave blank
